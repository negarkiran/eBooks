package com.kiran.streams;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import com.kiran.entity.Product;

public class FirstStreamExample {

	public static void main(String[] args) {
		List<Product> products = Arrays.asList(
				new Product(100,"iPhone X", 89000.00,"mobile"),
				new Product(101,"Sony Bravia", 125000.00,"tv"),
				new Product(102,"One + 5T", 45000.00,"mobile"),
				new Product(103,"iMac", 189000.00,"computer"),
				new Product(104,"LG OLED", 89000.00,"tv")
				);
		//traverse through product stream using consumer
		products.stream().forEach(p->System.out.println(p.getName()+" : "+p.getPrice()));
		products.stream().forEach(System.out::println);
		
		System.out.println("*********Map with Function***********");
		
		//transform using map
		Function<Product,String> getName = p->p.getName();
		products.stream().map(getName).forEach(System.out::println);
		
		System.out.println("*********Using Method Reference***********");
		products.stream().map(Product::getCategory).distinct().forEach(System.out::println);
		
		System.out.println("*********Using Filter***********");
		//print all mobiles
		products.stream().filter(p->"mobile".equalsIgnoreCase(p.getCategory())).map(getName).forEach(System.out::println);;
		
		System.out.println("*********Using Reduce***********");
		//reduce as terminal operation
		//get the total cost of all tvs
		double total = products.stream()
				.filter(p->"tv".equalsIgnoreCase(p.getCategory()))
				.map(p->p.getPrice())
				.reduce(0.0,(first,second)->first+second);
		System.out.println(total);
		
		System.out.println("*********Sort***********");
		products.stream()
		.filter(p->p.getCategory().equalsIgnoreCase("tv"))
		.sorted((p1,p2)->Double.compare(p1.getPrice(), p2.getPrice()))
		.forEach(System.out::println);
		
		System.out.println("*********Collectors***********");
		List<Product> tvs = products.stream()
				.filter(p-> p!=null && p.getCategory() !=null && "tv".equalsIgnoreCase(p.getCategory()))
				.collect(Collectors.toList());
		tvs.forEach(System.out::println);
		
		System.out.println("*********Collectors Group By***********");
		Map<String,List<Product>> productMap = products.stream().collect(Collectors.groupingBy(Product::getCategory));
		productMap.forEach((k,v)->{
			System.out.println("Product of Type :"+k);
			v.forEach(p->System.out.println(p.getName()+" : "+p.getPrice()));
			});
		
		System.out.println("*********Collectors Group By***********");
		Map<String,Long> productCountMap = products.stream().
							collect(Collectors.groupingBy(Product::getCategory,Collectors.counting()));
		System.out.println(productCountMap);
		
		System.out.println("*********parallel Streams***********");
		products.parallelStream()
		.filter(p->{
			System.out.println("Filter  "+ Thread.currentThread());
			return p.getCategory().equalsIgnoreCase("tv");
			})
		.sorted((p1,p2)->{
			System.out.println("Sorted  "+ Thread.currentThread());
			return Double.compare(p1.getPrice(), p2.getPrice());
			})
		.forEach(System.out::println);
		
		System.out.println("*********parallel Streams 2***********");
		Stream<Product> ps = products.stream().filter(p->p.getPrice()>50000.0);
		ps.parallel().forEach(System.out::println);
		
		int x = 100;
		products.stream().map(p->{
			int y = x+15;
			//x++;  will be implicit final 
			//Outer member is marked as final, when try to change inside lambda
			return p.getCategory();
		}).forEach(System.out::println);
		
		
		System.out.println("*********Int Streams ***********");
		IntStream intStream = IntStream.iterate(1, i->i+1);
				intStream
				.skip(5)
				.limit(100)
				.forEach(System.out::println);
		//Stream of collections
		Stream<List<Integer>> stream = Arrays.asList(Arrays.asList(1,3,6,8,4),Arrays.asList(23,54,23232)).stream();
		Stream<Integer> streamInteger = stream.flatMap(p->p.stream());
		streamInteger.filter(d -> d%2 ==0).forEach(System.out::println);
	}

}
