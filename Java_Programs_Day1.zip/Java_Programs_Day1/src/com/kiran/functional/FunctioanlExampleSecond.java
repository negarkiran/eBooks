package com.kiran.functional;

import java.util.function.BiFunction;
import java.util.function.Function;

public class FunctioanlExampleSecond {
	
	interface Operation<T,R>{
		R apply(T t);
		default <V> Operation<V, R> compose(Operation<? super V,? extends T> before){
			return (V v)-> apply(before.apply(v));
		}
	}
	

	public static void main(String[] args) {
		/*Function<Integer,Integer> f1 = t->t + 2;
		Function<Integer,Integer> f2 = t->t *2;*/
		
		Operation<Integer, Integer> f1 = t -> t + 2;
		Operation<Integer, Integer> f2 = t -> t * 2;
		
		System.out.println(f1.apply(5));
		System.out.println(f2.apply(3));
		
		System.out.println(f1.compose(f2).apply(3)); //first do f2 then do f1
		//System.out.println(f1.andThen(f2).apply(3)); //First do f1 operation and then do f2
		
		BiFunction<Integer, Integer, Double> f3 = (a,b)-> a/(double)b;
		System.out.println(f3.apply(5, 2));
	}

}
