package com.kiran.functional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

interface Consumer<T>{
	void accept(T t);
}

@FunctionalInterface
interface Predicate<T>{
	boolean test(T t);
	/*static void tetser() {
		
	}*/ //Allows Static and default methods
	
	/*default void yeys() {
		
	}*/
}

public class FunctioanlExample {
	//OCP Open Closed Principle of SOLID principles
	public static <T> List<T> filter(List<T> data, Predicate<T> predicate){
		List<T> values = new ArrayList<>();
		for(T obj:data) {
			if(predicate.test(obj)) {
				values.add(obj);
			}
		}
		return values;
	}
	
	public static <T> void iterate(List<T> data, Consumer<T> consumer) {
		for(T obj:data) {
			consumer.accept(obj);
		}
	}
	
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,22,344,55,22,12,17);
/*		Predicate<Integer> predicate = new Predicate<Integer>() {

			@Override
			public boolean test(Integer t) {
				return t % 2 == 0;
			}
		};
		*/
		//Replace above with Lambda expression
		//Predicate<Integer> predicate = t -> t % 2 == 0; //(t)->{return t % 2 == 0;}
		//List<Integer> evenList = filter(list,predicate);
		//List<Integer> evenList = filter(list,t->t % 2 == 0);
		List<Integer> evenList = filter(list,FunctioanlExample::isEven); //Method Reference
		
		//iterate(evenList, (t)->System.out.println(t));
		iterate(evenList, System.out::println);//Method Reference
	}
	
	private static boolean isEven(int number) {
		return number % 2 == 0;
	}

}
