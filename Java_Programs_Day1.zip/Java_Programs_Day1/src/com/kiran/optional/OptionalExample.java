package com.kiran.optional;

import java.util.Optional;

public class OptionalExample {

	public static void main(String[] args) {
		String name = null;
		//Optional<String> option = Optional.of(name);
		//option.ifPresent(System.out::println);
		Optional<String> option = Optional.ofNullable(name);
		
		System.out.println(option.orElse("Hello")); //option.get() results null pointer exception, so use orElse
		
		System.out.println(option.orElseGet(OptionalExample::getData));
		
	}

	private static String getData() {
		return "some data";
	}
}
