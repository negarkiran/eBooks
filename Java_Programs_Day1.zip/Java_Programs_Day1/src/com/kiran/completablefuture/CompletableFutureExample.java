package com.kiran.completablefuture;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class CompletableFutureExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		CompletableFuture<List<Integer>> cFuture = CompletableFuture.supplyAsync(CompletableFutureExample::getData);
		
		Thread.sleep(100);
		cFuture.complete(Arrays.asList(1,2,3));
		System.out.println(Thread.currentThread());
		
		//cFuture.get().forEach(System.out::println);
		cFuture.thenApply(data->{
			return data.stream().filter(d->d%2 ==0).collect(Collectors.toList());
		}).thenAccept(result->{
			result.forEach(System.out::println);
		});
		
		
		CompletableFuture<Void> cFuture2 = CompletableFuture.runAsync(()->System.out.println("Hello World"));
		cFuture.join();
		cFuture2.join();
	}
	
	public static List<Integer> getData(){
		System.out.println("Get Method->"+Thread.currentThread());
		try {
			Thread.sleep(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Arrays.asList(45,43,65,78,96,12);
	}

}
