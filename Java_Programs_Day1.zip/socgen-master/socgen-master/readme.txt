
Java 8

Banu Prakash C
banuprakashc@yahoo.co.in
banu@advantech-global.com
banu@lucidatechnologies.com

------------------------------------

	Java 5

	-> Generics
	-> java.util.concurrent [ Doug Lea ]
	-> Annotations

	Java 7
	-> RecursiveTask
	-> ForkJoinPool

	Java 8
		OOP 								Functional Programming
		method 								function
											SOLID ---> O ---> Open Close Princple

											not tightly coupled to state of Object



	Functional style Programming uses High Order functions.
	1) functions are passed as arguments to functions
	2) function returns a function

	Stream ----> Filter fn -----> Map fn ------> reduce fn

	function add(x,y) {
		return x + y;
	}


	Function add = new Function("x","y", "return x + y");



	List<Integer> list1 = Arrays.asList(1,6,9,34,7,2,10,18);

	write "map" High Order function which doubles each element and returns the result

	2 12 18 68 .....

	-------------------------------

	@Override ?

		1) Who uses this
		2) Where can I use this

	@FunctionalInterface
		--> Compiler

		@FunctionalInterface
		interface Consumer<T> {
			void accept(T obj);
		}



		Java 8 interface we can have:
			1) abstract methods
			2) default method
			3) static method

		@FunctionalInterface
		interface Op {
			void runOP(); // public abstract

			default long computeTime(Op op) {
				//start time
					op.runOp();
				// end time
			}

		}

		Java 8 common FunctionalInterfaces used:
		1) Predicate
		2) Consumer
		3) Supplier
		4) Function
		5) BiFunction
		6) Comparable
		7) Comparator
		8) Runnable
		9) Callable


		new Thread(() -> {

		});


		Java 8 streams
			Operations:
				a) Intermediate Operations
					filter, map, limit, skip, sample

				b) Terminal Operations
					reduce, forEach, collect


CompletableFuture:
-----------------

Future:
	-> container for a result that will become available at a later time
	-> Backed by a thread [ ExceutorService handles Future]
	-> may contain a throwable if computation fails
	-> means Asynchrouns
	-> does not mean non-blocking

	get() 
	cancel(false) --> Cancel future if not executed yet (in queue)
	cancel(true) --> cancel and in addition interrupt the running task
	isCancelled()
	isDone()

CompletableFuture
	-> All of Future +
	-> the result can be set once either by task itself or from outside
		complete(res) or completeExceptionally(Exception instance)
	-> composable
	-> lambda friendly

Computations can be be represented by a Future, Consumer or a Runnable with the respective method names of apply, accept or run
Execution of computations can be one of the following
Default execution (possibly the calling thread)
Async execution using the default async execution provider of the CompletionStage. These methods are denoted by the form of someActionAsync
Async execution by using a provided Executor. These methods also follow the form of someActionAsync but take an Executor instance as an additonal parameter.


CompletableFuture<Void> runAsync = 
				CompletableFuture.runAsync(() -> System.out.println("running async task"), service);

		Thread.sleep(1000);
		System.out.println(runAsync.isDone());
		service.shutdown();
		
		// supplyAsync accepts Supplier
		CompletableFuture<String> completableFuture = CompletableFuture.supplyAsync(() -> "Hello Java 8");
		System.out.println(completableFuture.get());

		// Processing Results of Asynchronous Computations
		// Consuming results of CompletableFutures
		List<String> results = new ArrayList<String>();
		CompletableFuture<String> task = CompletableFuture.supplyAsync(() -> "Hello Java 8");
		CompletableFuture<Void> acceptingTask = task.thenAccept(results::add);
		acceptingTask.get(); // void
		System.out.println(results);

		CompletableFuture<String> future = task.thenApply(s -> s + " World");
		System.out.println(future.get());


---------------------------------------

	
	Day 2
	-----

	@FunctionalInterface
		- 1 abstract method
		- can have default and static methods

	Function
	BiFunction
	Consumer
	Predicate
	Supplier


	Supplier<String> s = () -> "Hello";

	s.get(); // Hello


	public static Date getDate() {
		//...
	}


	Supplier<String> s = ClassName:getDate;


	------------

	Optional is a container which returns data or none

	-------------

	java.nio
		made us of this java 8 features to enhance file handling

	------------------------------

	Java 5
		Callable and Future

		Future
			--> container for async output
			--> does this result in blocking? YES
			--> get()
			
			--> cancel(false) // remove from submitted queue
			--> cancel(true) // interrupts in its already executing else to remove from submitted queue
			--> isDone()

		Using Future with Callbacks is painfull

	Future<T> f =  ...

		f.get(); // blocking

	RecurisveTask
	RecuresiveAction

		CompletableFuture
			allows composing many future tasks
			Functional style of programming

		Task1 ----> Task2 -----> Task3---->Task4

			can be used with Runnable, Future, Supplier

			can be executed on client thread
			can use default thread started by ForkJoinPool
			can use its own Exectors
-------------------------------------------------------------

		Third Party libiraries which are built on top of Java 8
		1) VAVR
		2) RxJava



		class Orders {

			List<Product> products = ....

			List<Product> getProducts() {
				return Collections.unmodifiableList(products);
			}

			// no Setters
		}

		---------------------


		public static Either<String,Employee> getEmployee(int no) {
			// hit the DB
			try{
				//
				Either.right(e);
			} catch(SQLException ex) {
				Either.left("Unable to get Employee " + ex.getMessage())
			}
		}

		https://github.com/BanuPrakash/socgen




