package com.banu.prg.entity.client;

import rx.Observable;

public class ReactiveExample {

	public static void main(String[] args) {

		Observable<Integer> observable = Observable.create(subscriber->{
			for(int i=0;i<20;i++) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				subscriber.onNext(i);
			}
			subscriber.onCompleted();
		});
		
		new Thread(()-> {
			observable.subscribe(data ->{
				System.out.println("First Got:"+data);
			},
			complete -> {
				System.out.println("DONE!!");
			});
		}).start();

		/*observable.publish();
		
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
		
		new Thread(()-> {
			observable.subscribe(data ->{
				System.out.println("Second Got:"+data);
			},
			complete -> {
				System.out.println("DONE!!");
			});
		}).start();
	}
	

}
