package com.banu.prg.entity.client;

import java.util.Hashtable;
import java.util.Vector;

import io.vavr.Function1;
import io.vavr.Function2;
import io.vavr.Tuple3;
import io.vavr.collection.List;

public class VAVRMisc {

	public static void main(String[] args) {
		Tuple3<String,Integer,Double> tuple3 = new Tuple3<String, Integer, Double>("Java", 8, 1.8);
		System.out.println(tuple3._1);
		System.out.println(tuple3._2);
		System.out.println(tuple3._3);
		
		tuple3.toSeq().forEach(System.out::println);
		
		Tuple3<String, Integer, Double> t2 = tuple3.update3(1.9);
		
		Tuple3<String, Integer, Double> t3 = tuple3.map(a->a.toUpperCase(),b->9,c->1.9);
		t3.toSeq().forEach(System.out::println);
		
		Function2<String,String,String> f = (greeting,name)->greeting+" "+name;
		
		Function1<String,String> f1 = f.curried().apply("Good Morning !");
		
		System.out.println(f1.apply("Harry"));
		System.out.println(f1.apply("Peter"));
		
		//Immutable Collections
		List<Integer> list = List.of(2,5,7,23,5,72); // immutable
		
		java.util.List<Integer> l1 = list.asJava();//converting to java util list which is mutable
		l1.forEach(System.out::println);
		List<Integer> list2 = List.ofAll(l1.stream()); //java -> VAVR
		
	}

}
