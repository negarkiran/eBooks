package com.banu.prg.entity.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MovieExample {

	public static void main(String[] args) {
		BufferedReader breader = null;
		try {
			Path path = Paths.get("src/main/resources", "movies.csv");
			breader = Files.newBufferedReader(path, StandardCharsets.ISO_8859_1);

		} catch (IOException exception) {
			System.out.println("Error occured while trying to read the file");
			System.exit(0);
		}

		List<String> lines = breader.lines().collect(Collectors.toList());
		//lines.stream().forEach(System.out::println);

		// To get the list of all movie names
		lines.stream()
		.skip(1).map(p->{
			return p.split(";")[0];
		}).forEach(System.out::println);;

		// To Get Director of "A Beautiful Mind"
		/*lines.stream().map(p->{
			return p.split(";")[0];
		}).filter(p->p!=null || p.equalsIgnoreCase(""))*/

		lines.stream()
		.skip(1)
		.map(line->Arrays.asList(line.split(";")))
		.filter(movie->{
			String movieName = movie.get(0);
			return movieName.trim().equalsIgnoreCase("A Beautiful Mind");
		})
		.forEach(movie->{
			String director = movie.get(2);
			System.out.println("A Beautiful Mind Director:"+director);
		});
		
		
		// Top 5 movies voted on IMDB [ Column 9]
		lines.stream()
		.skip(1)
		.map(line->Arrays.asList(line.split(";")))
		.filter(movie->{
			String imdbVotes = movie.get(9).trim();
			return !imdbVotes.equals("");})
		.sorted((movie1,movie2)->{
			String m1Votes = movie1.get(9).trim();
			String m2Votes = movie2.get(9).trim();
			return Integer.compare(Integer.valueOf(m2Votes), Integer.valueOf(m1Votes));})
		.limit(5)
		.forEach(movie->System.out.println(movie.get(0)+" : "+movie.get(9)));

	}

}
