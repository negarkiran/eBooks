package com.banu.prg.entity.client;

import io.vavr.Function1;
import io.vavr.Function2;
import io.vavr.control.Either;
import io.vavr.control.Option;

public class VAVRFunctionExample {

	public static Either<String,Integer> getData(int num){
		if(num < 50) {
			return Either.left("Not Eligible");
		}else{
			return Either.right(num +100);
		}
	}
	
	public static void main(String[] args) {
		
		Either<String,Integer> result = getData(24);
		if(result.isLeft()) {
			System.out.println(result.left().get());
		}else {
			System.out.println(result.right().get());
		}
		
		Function2<Integer, Integer, Integer> f1 = (x,y)->x/y;//partial function, can return value of throw exception
		
		System.out.println(f1.apply(8,5));
		
		System.out.println(f1.andThen(r->++r).apply(4,2));
		
		Function2<Integer, Integer, Option<Integer>> f2 = Function2.lift(f1); //Avoids exceptions and returns None
		System.out.println(f2.apply(8,2).get());
		
		Function1<Long, Long> f3 = Function1.of(VAVRFunctionExample::fibonacci).memoized(); //Uses Memoization
		
		long start = System.nanoTime();
		System.out.println(f3.apply(43L));
		long end = System.nanoTime();
		System.out.println("Total Time:"+(end-start));
		
		start = System.nanoTime();
		System.out.println(f3.apply(43L));
		end = System.nanoTime();
		System.out.println("Total Time:"+(end-start));
	}
	
	public static long fibonacci(long n) {
		if(n == 0 || n ==1)
			return n;
		else {
			return fibonacci(n-1)+fibonacci(n-2);
		}
	}

}
