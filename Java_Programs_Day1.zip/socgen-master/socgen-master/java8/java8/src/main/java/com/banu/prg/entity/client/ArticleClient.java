package com.banu.prg.entity.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.banu.prg.entity.Article;

public class ArticleClient {

	public static void main(String[] args) {
		List<Article> articles = new ArrayList<Article>();
		articles.add(new Article("NoDBA", 561, "bliki", Arrays.asList("nosql", "people", "orm")));
		articles.add(new Article("InfoDeck", 1145, "bliki", Arrays.asList("nosql", "writing")));
		articles.add(new Article("OrmHate", 1718, "bliki", Arrays.asList("nosql", "orm")));
		articles.add(new Article("ruby", 1313, "article", Arrays.asList("ruby")));
		articles.add(new Article("DDD_Aggregate", 482, "bliki", Arrays.asList("nosql", "ddd")));

		//get a total word count for all the articles in the list
		int totalWords = getTotalWords(articles);
		System.out.println("Total Words : " + totalWords); // 5219

		//figure out how many articles there are by each type
		Map<String, Long> articleMap = getCountByArticleType(articles); // {bliki: 4, article : 1}
		System.out.println(articleMap);
		
}
	
	
	private static Map<String, Long> getCountByArticleType(List<Article> articles) {
		return articles.stream().collect(Collectors.groupingBy(Article::getType,Collectors.counting()));
	}

	private static int getTotalWords(List<Article> articles) {
		return articles.stream().map(Article::getWords).reduce((a,b)->a+b).get();
	}

}
